import java.io.ByteArrayOutputStream;
import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.rmi.Naming;
import java.util.HashSet;
import java.util.Set;
import java.lang.*;
import java.io.*;

import org.w3c.dom.Node;

import com.axiomatics.delegent.server.EvaluationService;
import com.axiomatics.xacml.Constants;
import com.axiomatics.xacml.Indenter;
import com.axiomatics.xacml.attr.StringAttribute;
import com.axiomatics.xacml.ctx.Attribute;
import com.axiomatics.xacml.ctx.RequestCtx;
import com.axiomatics.xacml.ctx.RequestElement;

public class AuthorizationService {

    String rmiURL = null;
    String host = null;
    String rmiPort = null; 

    public AuthorizationService(String host, String rmiPort) {
	this.host = host;
	this.rmiPort = rmiPort; 
        rmiURL = "rmi://" + host + ":" + rmiPort + "/EvaluationService";
    }

    public void doAuthorization() {

	try {

        // Retrieve the EvaluationService object
        EvaluationService service =
            (EvaluationService) Naming.lookup(rmiURL);

        // Evaluate the XACML request
        // This is the PDP instance. You need to modify this to suit the 
        // PDP which are you are using.
	String instanceId = "ee087045-de7f-4909-b1de-5fe68b70f547";
        byte[] response = service.evaluate(instanceId, getRequest());

	//byte[][] r2 = service.evaluateWithTrace(instanceId, getRequest());

        // Print out the response
        System.out.println(new String(response));

	/*System.out.println("Before printing R2");
	System.out.println(new String(r2[0]));
	System.out.println("***** *****");
	System.out.println(new String(r2[1]));
	System.out.println("After printing R2");*/

	} 
	catch (java.rmi.NotBoundException nbe) {
	    nbe.printStackTrace();
	}
	catch (java.io.UnsupportedEncodingException encodingException) {
	    encodingException.printStackTrace();
	}
	catch (java.rmi.RemoteException rmt) {
	    rmt.printStackTrace();
	}
	catch (java.net.MalformedURLException malformedURN) {
	    malformedURN.printStackTrace();
	}
	catch (com.axiomatics.xacml.ParsingException parsingException) {
	    parsingException.printStackTrace();
	}
	catch (org.xml.sax.SAXException saxException) {
	    saxException.printStackTrace();
	}
	catch (com.axiomatics.delegent.server.PDPException pdpException) {
	    pdpException.printStackTrace();
	}
    }

    public byte[] getRequest() throws UnsupportedEncodingException {

	RequestElement subjectAttributeElement = getSubject();
	RequestElement resourceAttributeElement = getResource();
	RequestElement actionAttributeElement = getAction();

	Set<Attribute> envAttrs = new HashSet<Attribute>();

	RequestElement environmentAttributeElement = new RequestElement(Constants.ENVIRONMENT_CAT, envAttrs, null,
									    Constants.XACML_VERSION_2_0, true, null, 0);

        // Create a set of request elements that will then be passed into the xacml request constructor
        Set<RequestElement> reqElements = new HashSet<RequestElement>();

        // Add the request element we created  to the set
        reqElements.add(subjectAttributeElement);
        reqElements.add(resourceAttributeElement);
        reqElements.add(actionAttributeElement);
	reqElements.add(environmentAttributeElement);

        // Create the XACML request using the set of request elements
        Node documentRoot = null;
        RequestCtx xacmlRequest = new RequestCtx(reqElements, documentRoot, Constants.XACML_VERSION_2_0);
	//xacmlRequest.encode(System.out, null, new Indenter(1), null);

        ByteArrayOutputStream os = new ByteArrayOutputStream();
        xacmlRequest.encode(os, null, new Indenter(0), new HashSet<String>());
        byte[] req = os.toByteArray();

        System.out.println(new String(req));
        return req;
    }

    public RequestElement getSubject() 
    {
        // 1. create 1 or more attributes
        Attribute subjectAttribute = new Attribute(URI.create("urn:oasis:names:tc:xacml:1.0:subject:subject-id"), null, new StringAttribute("devdatta"), Constants.XACML_VERSION_2_0);

        // 2. create a set of attributes where to add all the attributes relating to a given category
        Set<com.axiomatics.xacml.ctx.Attribute> subjectAttributes = new HashSet<com.axiomatics.xacml.ctx.Attribute>();

        // 3. add the attributes to the set
        subjectAttributes.add(subjectAttribute);

        // 4. create a RequestElement object from the set of attributes specifying to what category they relate
        RequestElement reqElement = new RequestElement(Constants.SUBJECT_CAT, subjectAttributes, null, 
                Constants.XACML_VERSION_2_0, true, null, 0);
	
	return reqElement;
    }

    public RequestElement getResource() 
    {
        // 1. create 1 or more attributes
        Attribute resourceAttribute = new Attribute(URI.create("urn:oasis:names:tc:xacml:1.0:resource:resource-id"), null, new StringAttribute("devdatta"), Constants.XACML_VERSION_2_0);

        // 2. create a set of attributes where to add all the attributes relating to a given category
        Set<com.axiomatics.xacml.ctx.Attribute> resourceAttributes = new HashSet<com.axiomatics.xacml.ctx.Attribute>();

        // 3. add the attributes to the set
        resourceAttributes.add(resourceAttribute);

        // 4. create a RequestElement object from the set of attributes specifying to what category they relate
        RequestElement reqElement = new RequestElement(Constants.RESOURCE_CAT, resourceAttributes, null, 
                Constants.XACML_VERSION_2_0, true, null, 0);
	
	return reqElement;
    }

    public RequestElement getAction() 
    {
        // 1. create 1 or more attributes
        Attribute actionAttribute = new Attribute(URI.create("urn:oasis:names:tc:xacml:1.0:action:action-id"), null, new StringAttribute("changeUserPassword"), Constants.XACML_VERSION_2_0);

        // 2. create a set of attributes where to add all the attributes relating to a given category
        Set<com.axiomatics.xacml.ctx.Attribute> actionAttributes = new HashSet<com.axiomatics.xacml.ctx.Attribute>();

        // 3. add the attributes to the set
        actionAttributes.add(actionAttribute);

        // 4. create a RequestElement object from the set of attributes specifying to what category they relate
        RequestElement reqElement = new RequestElement(Constants.ACTION_CAT, actionAttributes, null, 
                Constants.XACML_VERSION_2_0, true, null, 0);
	
	return reqElement;
    }    
}