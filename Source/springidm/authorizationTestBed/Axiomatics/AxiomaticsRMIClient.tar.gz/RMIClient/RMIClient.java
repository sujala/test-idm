import java.io.ByteArrayOutputStream;
import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.rmi.Naming;
import java.util.HashSet;
import java.util.Set;

import org.w3c.dom.Node;

import com.axiomatics.delegent.server.EvaluationService;
import com.axiomatics.xacml.Constants;
import com.axiomatics.xacml.Indenter;
import com.axiomatics.xacml.attr.StringAttribute;
import com.axiomatics.xacml.ctx.Attribute;
import com.axiomatics.xacml.ctx.RequestCtx;
import com.axiomatics.xacml.ctx.RequestElement;

public class RMIClient {

    public static void main(String[] args) throws Exception {

        // Construct the RMI URL
        String host = "184.106.205.174";
        String rmiPort = "11099";
	
	AuthorizationService authorizationService = new AuthorizationService(host, rmiPort);

	System.out.println("=== Before authorization == ");
	authorizationService.doAuthorization();
	System.out.println("=== After authorization == ");
    }
}
