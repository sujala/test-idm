#!/bin/sh

AX_HOME=/Users/devdatta.kulkarni/Axiomatics/xacmlAuthService/lib

TOMCATLIB=/Users/devdatta.kulkarni/Axiomatics/demo/src/lib/tomcat6-lib

CLASSPATH=.

CLASSPATH=$CLASSPATH:/Users/devdatta.kulkarni/Axiomatics/PAP/lib/axio-xacml.jar
CLASSPATH=$CLASSPATH:/Users/devdatta.kulkarni/Axiomatics/PAP/lib/axio-xacml-request-api.jar
CLASSPATH=$CLASSPATH:/Users/devdatta.kulkarni/Axiomatics/PAP/lib/commons-logging.jar
CLASSPATH=$CLASSPATH:/Users/devdatta.kulkarni/Axiomatics/PAP/lib/commons-logging-api.jar
CLASSPATH=$CLASSPATH:/Users/devdatta.kulkarni/Axiomatics/PAP/lib/commons-codec-1.3.jar
CLASSPATH=$CLASSPATH:/Users/devdatta.kulkarni/Axiomatics/PAP/lib/delegent.jar
CLASSPATH=$CLASSPATH:/Users/devdatta.kulkarni/Axiomatics/PAP/lib/log4j-1.2.14.jar
CLASSPATH=$CLASSPATH:/Users/devdatta.kulkarni/Axiomatics/PAP/lib/delegent-pap-service.jar
CLASSPATH=$CLASSPATH:/Users/devdatta.kulkarni/Axiomatics/PAP/lib/xmlsec-1.4.2.jar
CLASSPATH=$CLASSPATH:/Users/devdatta.kulkarni/Axiomatics/PAP/lib/forms-1.2.0.jar
CLASSPATH=$CLASSPATH:/Users/devdatta.kulkarni/Axiomatics/PAP/lib/jargs.jar
CLASSPATH=$CLASSPATH:/Users/devdatta.kulkarni/Axiomatics/PAP/lib/swingx-0.9.3.jar
CLASSPATH=$CLASSPATH:/Users/devdatta.kulkarni/Axiomatics/PAP/lib/swing-worker-1.2.jar
CLASSPATH=$CLASSPATH:/Users/devdatta.kulkarni/Axiomatics/PAP/lib/truexml.jar
CLASSPATH=$CLASSPATH:/Users/devdatta.kulkarni/Axiomatics/PAP/lib/truelicense.jar
CLASSPATH=$CLASSPATH:/Users/devdatta.kulkarni/Axiomatics/PAP/lib/delegent-metro-client.jar
CLASSPATH=$CLASSPATH:/Users/devdatta.kulkarni/Axiomatics/PAP/lib/delegent-pap-client-gui.jar
CLASSPATH=$CLASSPATH:/Users/devdatta.kulkarni/Axiomatics/PAP/lib/delegent-pap-client-gui-metro.jar
CLASSPATH=$CLASSPATH:/Users/devdatta.kulkarni/Axiomatics/PAP/lib/webservices-api.jar
CLASSPATH=$CLASSPATH:/Users/devdatta.kulkarni/Axiomatics/PAP/lib/webservices-extra-api.jar
CLASSPATH=$CLASSPATH:/Users/devdatta.kulkarni/Axiomatics/PAP/lib/webservices-extra.jar
CLASSPATH=$CLASSPATH:/Users/devdatta.kulkarni/Axiomatics/PAP/lib/webservices-rt.jar

export CLASSPATH

javac -cp $CLASSPATH *.java

echo $CLASSPATH