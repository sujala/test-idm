import java.io.*;
import java.lang.*;
import com.sun.xacml.PDP;

import com.sun.xacml.ctx.RequestCtx;
import com.sun.xacml.ctx.ResponseCtx;

import com.sun.xacml.ctx.*;
import com.sun.xacml.attr.AttributeValue;
import com.sun.xacml.attr.*;
import com.sun.xacml.*;

import java.io.FileInputStream;
import java.net.*;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class ClientService 
{
    private AuthorizationService authorizationService;
    String resId;
    String subId;
    String acId;
    
    public ClientService(String resourceName, String subjectName, String actionName)
    {
	this.resId = resourceName;
	this.subId = subjectName;
	this.acId = actionName;
	  
	try {
	    authorizationService = new AuthorizationService();
	}
	catch(Exception exp)
	{
	    exp.printStackTrace();
	}
    }

    private void run()
    {
        testAuthorization();
    }

    private void testAuthorization()
    {
	try {
	    Set subjects = getSubjects();
            Set resource = getResource();
            Set action = getAction();
            Set environment = new HashSet();

            RequestCtx request = new RequestCtx(subjects, resource, action, environment);

	    System.out.println("Request created");

	    writeRequestToFile(request, "Request.txt");

            System.out.println("=== Before doing Authorization ===");

            ResponseCtx response = authorizationService.doAuthorization(request);

            System.out.println("=== Authorization done ===");

	    writeResponseToFile(response, "Response.txt");

	    System.out.println("Check the response in Response.txt file");
	} 
	catch (Exception exp)
	{
	    exp.printStackTrace();
        }
    }

    private Set getSubjects()
    {
        try {
            HashSet subjects = new HashSet();
            HashSet subjectAttributes = new HashSet();

            URI subjectID = new URI("urn:oasis:names:tc:xacml:1.0:subject:subject-id");
            String issuer = null;
            DateTimeAttribute dateTime = null; //new DateTimeAttribute();                                                                                                       
            //StringAttribute subjectName = new StringAttribute("Julius Hibbert");
	    //StringAttribute subjectName = new StringAttribute(subjectName);
	    StringAttribute subjectName = new StringAttribute(subId);
            Attribute subjectIdAttribute = new Attribute(subjectID, issuer, dateTime, subjectName);

            subjectAttributes.add(subjectIdAttribute);

            Subject user = new Subject(subjectAttributes);
            subjects.add(user);

            return subjects;
        }
        catch (URISyntaxException uriSyntaxException)
	{
	    uriSyntaxException.printStackTrace();
	    return null;
	}
    }

    private Set getAction()
    {
        HashSet action = new HashSet();
        try {
	    URI actionID = new URI("urn:oasis:names:tc:xacml:1.0:action:action-id");
	    String issuer = null;
	    DateTimeAttribute dateTime = null; //new DateTimeAttribute();                                                                                                           
	    StringAttribute actionName = new StringAttribute(acId);
	    Attribute actionIdAttribute = new Attribute(actionID, issuer, dateTime, actionName);
	    action.add(actionIdAttribute);
        }
        catch (URISyntaxException uriSyntaxException)
	    {
                uriSyntaxException.printStackTrace();
                return null;
	    }
        return action;
    }


    private Set getResource()
    {
        HashSet resource = new HashSet();
        try {
	    URI resourceID = new URI("urn:oasis:names:tc:xacml:1.0:resource:resource-id");
	    String issuer = null;
	    DateTimeAttribute dateTime = null; //new DateTimeAttribute();
	    //AnyURIAttribute resourceURI = new AnyURIAttribute(new URI("http://medico.com/record/patient/BartSimpson"));
	    StringAttribute resourceName = new StringAttribute(resId);
	    Attribute resourceIdAttribute = new Attribute(resourceID, issuer, dateTime, resourceName);

	    resource.add(resourceIdAttribute);

        }
        catch (URISyntaxException uriSyntaxException)
	    {
                uriSyntaxException.printStackTrace();
                return null;
	    }
        return resource;
    }

    private void writeRequestToFile(RequestCtx request, String fileName)
    {
        try {
	    OutputStream requestStream = new FileOutputStream(fileName);
	    request.encode(requestStream, new Indenter());
        }
        catch(Exception exp)
            {
                exp.printStackTrace();
            }
    }

    private void writeResponseToFile(ResponseCtx response, String fileName)
    {
        try {
	    OutputStream responseStream = new FileOutputStream(fileName);
	    response.encode(responseStream, new Indenter());
        }
        catch(Exception exp)
            {
                exp.printStackTrace();
            }
    }

    private void printRequest(Set subjects, Set actions, Set resource, Set environment)
    {
        System.out.println("=== Printing Subject Attributes ===");
        for(Iterator it = subjects.iterator(); it.hasNext();)
	    {
		Subject subject = (Subject) it.next();
		Set subAttrs = subject.getAttributes();

		for (Iterator it1 = subAttrs.iterator(); it1.hasNext();)
		    {
			Attribute attr = (Attribute) it1.next();
			printAttribute(attr);
		    }
	    }

        System.out.println("=== Printing Action Attributes ===");
        for(Iterator it = actions.iterator(); it.hasNext();)
	    {
		Attribute actionAttrs = (Attribute) it.next();
		printAttribute(actionAttrs);
	    }

        System.out.println("=== Printing Resource Attributes ===");
        for(Iterator it = resource.iterator(); it.hasNext();)
	    {
		Attribute resourceAttrs = (Attribute) it.next();
		printAttribute(resourceAttrs);
	    }

        System.out.println("=== Printing Environment Attributes === " + environment.toString());
        if ( environment != null ) // environment can be optional and hence null.                                                                                               
	    {
		for(Iterator it = environment.iterator(); it.hasNext();)
		    {
			Attribute environmentAttrs = (Attribute) it.next();
			printAttribute(environmentAttrs);
		    }
	    }
    }

    private void printAttribute(Attribute attr)
    {
        URI id = attr.getId();
        String issuer = attr.getIssuer();
        URI type = attr.getType();
        AttributeValue value = attr.getValue();
        System.out.println("Attribute ID:" + id);
        System.out.println("Attribute Issuer:" + issuer);
        System.out.println("Attribute Type:" + type);
        System.out.println("Attribute Value:" + value.toString());
    }

    public static void main(String [] args) 
    {
	if (args.length < 3) 
	    {
		System.out.println("Usage: java ClientService <resource name> <subject name> <action name>");
		System.exit(0);
	    }

	String resourceName = args[0];
	String subjectName = args[1];
	String actionName = args[2];

	System.out.println("Res:" + resourceName + " Subject:" + subjectName + " Action:" + actionName);

	ClientService clientService = new ClientService(resourceName, subjectName, actionName);
	clientService.run();
    }
}